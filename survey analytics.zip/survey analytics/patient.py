# -*- coding: utf-8 -*-
"""
Created on Sun Nov  1 12:43:42 2020

@author: AAYUSH VOHRA
"""

import pandas as pd
# Loading the the survival un-employment data
Patient = pd.read_csv("G:/practical data science/Assignments/survey analytics/Patient.csv")
Patient.head()
Patient.describe()
Patient["Followup"].describe()
# Spell is referring to time 
T = Patient.Followup
#Importing the KaplanMeierFitter model to fit the survival analysis
from lifelines import KaplanMeierFitter
# Initiating the KaplanMeierFitter model
kmf = KaplanMeierFitter()

# Fitting KaplanMeierFitter model on Time and Events for death 
kmf.fit(T, event_observed=Patient.Eventtype)

# Time-line estimations plot 
kmf.plot()

# Over Multiple groups 
# For each group, here group is ui
Patient.Scenario.value_counts()

# Applying KaplanMeierFitter model on Time and Events for the group "1"
kmf.fit(T[Patient.Scenario==1], Patient.Eventtype[Patient.Scenario==1], label='1')
ax = kmf.plot()

# Applying KaplanMeierFitter model on Time and Events for the group "0"
kmf.fit(T[Patient.Scenario==0], Patient.Eventtype[Patient.Scenario==0], label='0')
kmf.plot(ax=ax)
