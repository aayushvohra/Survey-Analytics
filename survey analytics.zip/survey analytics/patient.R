# Survival Analysis in R

# install.packages('survminer')
# install.packages("survival")

library(survminer)
library(survival)

??survminer
??survival
patient <- read.csv(file.choose())

attach(patient)
str(patient)
# Define variables 
PatientID <-PatientID
time <- Followup
event <- Eventtype
group <- Scenario 
# Descriptive statistics
summary(PatientID)
summary(time)
table(event)
table(group)

# Kaplan-Meier non-parametric analysis
kmsurvival <- survfit(Surv(time, event) ~ 1)

summary(kmsurvival)

plot(kmsurvival, xlab="Time", ylab="Survival Probability")

ggsurvplot(kmsurvival, data=patient, risk.table = TRUE)
# Kaplan-Meier non-parametric analysis by group
kmsurvival1 <- survfit(Surv(time, event) ~ group)
summary(kmsurvival1)

plot(kmsurvival1, xlab="Time", ylab="Survival Probability")
ggsurvplot(kmsurvival1, data=patient, risk.table = TRUE)
